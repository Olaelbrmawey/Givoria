// ملف: navbar.js
document.addEventListener('DOMContentLoaded', function() {
    // تحديد العناصر
    const authButtons = document.getElementById('auth-buttons');
    const profileSection = document.getElementById('profile-section');
    const logoutBtn = document.getElementById('logoutBtn');
    
    // حالة المستخدم (تعديلها حسب نظامك)
    let isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    let currentUsername = localStorage.getItem('username') || 'User';
    
    // تحديث الواجهة
    function updateAuthUI() {
      if (isLoggedIn) {
        authButtons.style.display = 'none';
        profileSection.style.display = 'block';
        document.getElementById('usernameDisplay').textContent = currentUsername;
      } else {
        authButtons.style.display = 'flex';
        profileSection.style.display = 'none';
      }
    }
    
    // معالجة تسجيل الخروج
    if (logoutBtn) {
      logoutBtn.addEventListener('click', function(e) {
        e.preventDefault();
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('username');
        isLoggedIn = false;
        updateAuthUI();
        window.location.href = 'index.html';
      });
    }
    
    // التهيئة الأولية
    updateAuthUI();
    
    // إضافة active class للصفحة الحالية
    const currentPage = window.location.pathname.split('/').pop();
    document.querySelectorAll('.nav-link').forEach(link => {
      if (link.getAttribute('href') === currentPage) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  });