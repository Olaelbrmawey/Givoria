document.getElementById("feedbackForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the form from submitting

    // Get form values
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let feedback = document.getElementById("feedback").value;

    // Basic validation
    if (!name || !email || !feedback) {
        alert("Please fill out all fields.");
        return;
    }

    // Display a confirmation message
    alert("Thank you for your feedback. We will review it soon.");

    // Clear the form
    document.getElementById("feedbackForm").reset();
});