function toggleMedicalReport() {
    const doctorReport = document.getElementById('doctorReport').value;
    const uploadSection = document.getElementById('medicalReportUpload');
    uploadSection.style.display = (doctorReport === "Yes") ? 'block' : 'none';
}

document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('deviceRequestForm');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        Swal.fire({
            title: 'Request Received!',
            text: 'Thank you! Your request will be reviewed and you will be contacted shortly.',
            icon: 'info',
            confirmButtonText: 'OK',
            showClass: {
                popup: 'animate__animated animate__fadeIn'
            },
            hideClass: {
                popup: 'animate__animated animate__fadeOut'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                form.reset();
                toggleMedicalReport(); // Hide report section if it was shown
            }
        });
    });
});