 // Show/hide more text
document.getElementById('readMoreBtn')?.addEventListener('click', function () {
  const moreText = document.getElementById('moreText');
  if (moreText.classList.contains('hidden')) {
    moreText.classList.remove('hidden');
    this.textContent = 'Read Less';
  } else {
    moreText.classList.add('hidden');
    this.textContent = 'Read More';
  }
});

// Filter opportunities
 window.onload = function () {
  window.filterCategory = function(category) {
    const cards = document.querySelectorAll('.opportunity');
    cards.forEach(card => {
      card.style.display = (category === 'all' || card.classList.contains(category)) ? 'block' : 'none';
    });
  };
};


// Open and close application form
function openForm() {
  document.getElementById('applyForm').style.display = 'block';
}

document.getElementById('closeBtn')?.addEventListener('click', () => {
  document.getElementById('applyForm').style.display = 'none';
});

// Counter animation
const counters = document.querySelectorAll('.counter');
counters.forEach(counter => {
  const updateCount = () => {
    const target = +counter.getAttribute('data-target');
    const count = +counter.innerText;
    const speed = 200;
    const increment = target / speed;

    if (count < target) {
      counter.innerText = Math.ceil(count + increment);
      setTimeout(updateCount, 10);
    } else {
      counter.innerText = target;
    }
  };
  updateCount();
});

// Scroll animation for fade-in elements
const faders = document.querySelectorAll('.fade-in');

const appearOptions = {
  threshold: 0.1,
  rootMargin: "0px 0px -50px 0px"
};

const appearOnScroll = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add('visible');
    observer.unobserve(entry.target);
  });
}, appearOptions);

faders.forEach(fader => {
  appearOnScroll.observe(fader);
});

  const badges = document.getElementById('causeBadges');
  const hiddenInput = document.getElementById('causesSelected');
  const addMoreBtn = document.getElementById('addMoreBadge');
  const newCauseInput = document.getElementById('newCauseInput');

  function updateSelected() {
    const selected = Array.from(badges.querySelectorAll('.badge.active'))
      .filter(b => !b.classList.contains('add-more'))
      .map(b => b.dataset.value);
    hiddenInput.value = selected.join(',');
  }

  badges.addEventListener('click', (e) => {
    if (e.target.classList.contains('badge') && !e.target.classList.contains('add-more')) {
      e.target.classList.toggle('active');
      updateSelected();
    }
  });

  addMoreBtn.addEventListener('click', () => {
    newCauseInput.style.display = 'inline-block';
    newCauseInput.focus();
  });

  newCauseInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const value = newCauseInput.value.trim();
      if (value) {
        const newBadge = document.createElement('span');
        newBadge.className = 'badge active';
        newBadge.dataset.value = value.toLowerCase().replace(/\s+/g, '-');
        newBadge.textContent = value;
        badges.insertBefore(newBadge, addMoreBtn);
        newCauseInput.value = '';
        newCauseInput.style.display = 'none';
        updateSelected();
      }
    }
  });
  function openForm() {
    alert("You need to log in or sign up first."); // الرسالة اللي بتفكر المستخدم
    document.getElementById('applyForm').style.display = 'block'; // بعدها يظهر الفورم عادي
  }
  
  
 