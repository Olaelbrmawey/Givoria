
document.addEventListener('DOMContentLoaded', function () {
    // Variables
    let currentStep = 1;
    const totalSteps = 5;
    const formData = {
      amount: '',
      paymentMethod: '',
      cardNumber: '',
      walletNumber: '',
      emailPayPal: '',
      name: '',
      email: '',
      phone: ''
    };
  
    // Elements
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const progressBar = document.getElementById('progressBar');
    const stepTitle = document.getElementById('stepTitle');
    const currentStepEl = document.getElementById('currentStep');
    const paymentDetails = document.getElementById('paymentDetails');
    const steps = document.querySelectorAll('.step');
  
    const titles = [
      'Select Amount',
      'Choose Payment Method',
      'Your Information',
      'Confirm Details',
      'Thank You!'
    ];
  
    // UI Update
    function updateUI() {
      steps.forEach(step => step.style.display = 'none');
      document.getElementById(`step${currentStep}`).style.display = 'block';
  
      stepTitle.textContent = titles[currentStep - 1];
      currentStepEl.textContent = currentStep;
      progressBar.style.width = `${(currentStep / totalSteps) * 100}%`;
  
      prevBtn.style.display = currentStep === 1 ? 'none' : 'inline-block';
      nextBtn.textContent = currentStep === totalSteps - 1 ? 'Confirm' : (currentStep === totalSteps ? 'Finish' : 'Next');
      nextBtn.style.display = currentStep === totalSteps ? 'none' : 'inline-block';
    }
  
    // Update Confirmation Details
    function updateConfirmation() {
      document.getElementById('confirmAmount').textContent = `$${formData.amount}` || '-';
      document.getElementById('confirmMethod').textContent = formData.paymentMethod || '-';
      document.getElementById('confirmName').textContent = formData.name || '-';
      document.getElementById('confirmEmail').textContent = formData.email || '-';
      document.getElementById('confirmPhone').textContent = formData.phone || '-';
    }
  
    // Payment Method Details Handler
    function updatePaymentDetails(method) {
      let html = '';
  
      if (['Visa', 'Meeza'].includes(method)) {
        html = `
          <label for="cardNumber">Card Number</label>
          <input type="text" id="cardNumber" maxlength="19" placeholder="xxxx xxxx xxxx xxxx">
          <label for="expiryDate">Expiry Date</label>
          <input type="text" id="expiryDate" placeholder="MM/YY">
          <label for="cvv">CVV</label>
          <input type="text" id="cvv" maxlength="4" placeholder="CVV">
        `;
      } else if (['Vodafone Cash', 'Orange Money', 'Etisalat Cash', 'We Pay'].includes(method)) {
        html = `
          <label for="walletNumber">Wallet Number</label>
          <input type="tel" id="walletNumber" placeholder="Eg. 01012345678">
        `;
      } else if (method === 'PayPal') {
        html = `
          <label for="emailPayPal">PayPal Email</label>
          <input type="email" id="emailPayPal" placeholder="example@paypal.com">
        `;
      } else if (method === 'Fawry') {
        html = `<p>You will receive a Fawry reference code after submission.</p>`;
      } else if (method === 'Bank Transfer') {
        html = `<p>Please transfer to Bank: NBE, Acc No: 1234567890</p>`;
      } else if (method === 'Instapay') {
        html = `<label for="instapayCode">Enter InstaPay Code</label><input type="text" id="instapayCode" placeholder="123-456-789">`;
      }
  
      paymentDetails.innerHTML = html;
  
      // Attach Inputs Events After Rendering
      if (document.getElementById('cardNumber')) {
        document.getElementById('cardNumber').addEventListener('input', (e) => {
          let value = e.target.value.replace(/\D/g, '').substring(0,16);
          e.target.value = value.match(/.{1,4}/g)?.join(' ') || value;
          formData.cardNumber = value;
        });
      }
      if (document.getElementById('walletNumber')) {
        document.getElementById('walletNumber').addEventListener('input', (e) => formData.walletNumber = e.target.value);
      }
      if (document.getElementById('emailPayPal')) {
        document.getElementById('emailPayPal').addEventListener('input', (e) => formData.emailPayPal = e.target.value);
      }
    }
  
    // Validation
    function validateStep() {
      switch (currentStep) {
        case 1:
          if (!formData.amount) {
            alert('Please select or enter an amount');
            return false;
          }
          break;
        case 2:
          if (!formData.paymentMethod) {
            alert('Please select a payment method');
            return false;
          }
          break;
        case 3:
          if (!formData.name || !formData.email || !formData.phone) {
            alert('Please complete your info');
            return false;
          }
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
            alert('Invalid Email Address');
            return false;
          }
          break;
      }
      return true;
    }
  
    // Events
  
    // Amount buttons
    document.querySelectorAll('.amount-btn').forEach(btn => {
      btn.addEventListener('click', function () {
        document.querySelectorAll('.amount-btn').forEach(b => b.classList.remove('selected'));
        this.classList.add('selected');
        formData.amount = this.dataset.amount;
        document.getElementById('customAmount').value = '';
      });
    });
  
    // Custom Amount input
    document.getElementById('customAmount').addEventListener('input', function () {
      document.querySelectorAll('.amount-btn').forEach(btn => btn.classList.remove('selected'));
      formData.amount = this.value;
    });
  
    // Payment Methods
    document.querySelectorAll('.payment-method').forEach(method => {
      method.addEventListener('click', function () {
        document.querySelectorAll('.payment-method').forEach(m => m.classList.remove('selected'));
        this.classList.add('selected');
        formData.paymentMethod = this.dataset.method;
        updatePaymentDetails(formData.paymentMethod);
      });
    });
  
    // Personal Info Inputs
    document.getElementById('name').addEventListener('input', (e) => formData.name = e.target.value);
    document.getElementById('email').addEventListener('input', (e) => formData.email = e.target.value);
    document.getElementById('phone').addEventListener('input', (e) => formData.phone = e.target.value);
  
    // Next Step
    nextBtn.addEventListener('click', () => {
      if (validateStep()) {
        if (currentStep === totalSteps - 1) {
          updateConfirmation();
        }
        currentStep++;
        updateUI();
      }
    });
  
    // Previous Step
    prevBtn.addEventListener('click', () => {
      if (currentStep > 1) {
        currentStep--;
        updateUI();
      }
    });
  
    // Initialize
    updateUI();
  });